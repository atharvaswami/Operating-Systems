#include <chrono>
#include <cmath>
#include <vector>
#include <bits/stdc++.h>

using namespace std;
using namespace std::chrono;

struct pixel{
    int r, g, b;
};

